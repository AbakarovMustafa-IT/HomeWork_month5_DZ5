import React from "react";

function User({ name }) {
  return (
    <p>{name}</p>
  )
}

export default User